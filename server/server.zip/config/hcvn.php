<?php

return [
    'table_names' => [
        'provinces' => 'provinces',
        'districts' => 'districts',
        'wards' => 'wards',
    ]
];

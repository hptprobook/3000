<a href="/api/docs">API</a>
<?php /**PATH D:\Workspace\project\3000\server\resources\views/welcome.blade.php ENDPATH**/ ?>
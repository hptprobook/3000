<a href="/api/docs">API</a>
<?php /**PATH /mnt/d/Workspace/project/3000/server/resources/views/welcome.blade.php ENDPATH**/ ?>